package com.swifteh;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.ResultSet;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandExecutor;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class SlowVote extends JavaPlugin implements Listener, CommandExecutor {

	private String host = "localhost";
	private String port = "3306";
	private String username = "slowvote";
	private String password = "password";
	private String database = "Voting";
	private String warning;
	private String pastDue;
	private boolean debug = false;
//	private HashMap<Player, Long> taskList = new HashMap<Player, Long>();
	MySQLDatabase mySQLDatabase;
	static final float defaultRunSpeed = (float) 0.2;

	@Override
	public void onEnable() {
		try {
			File f = new File(getDataFolder().getAbsolutePath());
			if (!f.exists()) f.mkdirs();
			f = new File(getDataFolder().getAbsolutePath() + "/config.txt");
			if (!f.exists()){
				
				BufferedWriter out = new BufferedWriter(new FileWriter(f));
				out.write("warning:RealmCraft needs your vote to stay alive! If you don't vote in the next %TIME% " +
						"minutes, you will be slowed");
				out.newLine();
				out.write("past:You have been slowed because you have not voted!");
				out.newLine();
				out.write("host:");
				out.newLine();
				out.write("port:");
				out.newLine();
				out.write("username:");
				out.newLine();
				out.write("password:");
				out.newLine();
				out.write("database:");
				out.newLine();
				out.write("debug:");
				out.close();
			}
			BufferedReader in = new BufferedReader(new FileReader(f));
			String s;
			while ((s = in.readLine()) != null){
				if (s.startsWith("warning:")){
					warning = s.substring(8, s.length() - 1);
					warning = ChatColor.translateAlternateColorCodes('&', warning);
				}
				else if (s.startsWith("past:")){
					pastDue = s.substring(5, s.length() - 1);
					pastDue = ChatColor.translateAlternateColorCodes('&', pastDue);
				}
				else if (s.startsWith("host")) host = s.substring(5, s.length());
				else if (s.startsWith("port")) port = s.substring(5, s.length());
				else if (s.startsWith("username")) username = s.substring(9, s.length());
				else if (s.startsWith("password")) password = s.substring(9, s.length());
				else if (s.startsWith("database")) database = s.substring(9, s.length());
				else if (s.startsWith("debug")) debug = true;
			}
			mySQLDatabase = new MySQLDatabase(host, port, username, password, database);
			mySQLDatabase.open();
			in.close();
			this.getServer().getScheduler().runTaskTimer(this, new Runnable(){
				@Override
				public void run() {
					ResultSet result;
					for(Player p : Bukkit.getOnlinePlayers()){
						try{
							result = mySQLDatabase.query("SELECT timestamp FROM Votes WHERE LOWER(User) = '" 
									+ p.getName().toLowerCase() + "';");
							if (debug)
								Bukkit.getLogger().info("Player: " + p.getName() + " result:" + result.first());
							if (result.first()) {
								double difference = System.currentTimeMillis() - result.getTimestamp(1).getTime();
								difference = difference/(1000D * 60D);//Minutes
								if (debug)
									Bukkit.getLogger().info("Diff: " + difference);
								if ((difference / 60) > 28) {
//									if (debug)
//										Bukkit.getLogger().info("Setting walk speed to " + defaultRunSpeed/2 + " from " + p.getWalkSpeed());
//									p.setWalkSpeed(defaultRunSpeed/2);
									p.removePotionEffect(PotionEffectType.SLOW);
									p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 600, 2, true));
									p.sendMessage(ChatColor.RED + pastDue);
								}
								else if (difference > 1675) {
									String copy = warning;
									copy.replace("%TIME%", String.valueOf(difference));
									p.sendMessage(ChatColor.RED + copy);
								}
//								else{
////									p.setWalkSpeed(defaultRunSpeed);
//									if (debug)
//										Bukkit.getLogger().info("Setting walk speed to " + defaultRunSpeed + " from " + p.getWalkSpeed());
//								}
									
							}
						}
						catch(Exception e){
							e.printStackTrace();
							continue;
						}
					}
				}
			}, 1L, 600L);
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onDisable() {
		try {
			mySQLDatabase.close();
		} catch (final Exception e) {

		}
	}
	
	@EventHandler
	public void OnJoin(PlayerJoinEvent e) {
		try {
			ResultSet result = mySQLDatabase.query("SELECT timestamp FROM Votes WHERE LOWER(User) = '" 
					+ e.getPlayer().getName().toLowerCase() + "';");
			if (result.next())
				return;
			if(mySQLDatabase.create("INSERT INTO `" + database + "`.`votes`(`User`, `timestamp`) VALUES" +
					"('" + e.getPlayer().getName().toLowerCase() + "', NOW());"))
				Bukkit.getLogger().info("Created table data for " + e.getPlayer().getName());
			else
				Bukkit.getLogger().info("Could not create table data for " + e.getPlayer().getName());
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	@EventHandler
	public void onSprint(PlayerToggleSprintEvent event)
	{
		boolean sprinting = event.isSprinting();
		if (!sprinting) return;
		if (event.getPlayer().getWalkSpeed() == 0.5) event.setCancelled(true);
	}

//	public void slow(Player player) {
//		Calendar cal = Calendar.getInstance();
//		cal.add(Calendar.DATE, -1);
//		Date yesterday = new Date(cal.getTimeInMillis());
//		ResultSet result;
//		try {
//			result = mySQLDatabase.query("SELECT timestamp FROM Votes WHERE LOWER(User) = '" + player.getName().toLowerCase() + "';");
//			if (result.first()) {
//				if (result.getTimestamp(1).after(yesterday)) {
//					if (taskList.containsKey(player)) {
//						getServer().getScheduler().cancelTask(taskList.get(player));
//						taskList.remove(player);
//					}
//					result.close();
//					return;
//				}
//			}
//			result.close();
//			player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 1200, 1), true);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	
}
